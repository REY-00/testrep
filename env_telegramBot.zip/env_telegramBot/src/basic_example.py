from telegram.ext import MessageHandler, Filters
from telegram.ext import Updater
from telegram.ext import CommandHandler
from telegram.ext import MessageHandler, Filters
import pyfirmata
import logging


board = pyfirmata.Arduino('/dev/ttyUSB0')
updater = Updater(token='1148088792:AAEIDXAi7HvIen0X_mi1WWEBWHCgvQXNwqI', use_context=True)
dispatcher = updater.dispatcher


logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                     level=logging.INFO)


def start(update, context):
    context.bot.send_message(chat_id=update.effective_chat.id, text="Please talk to me Liza!")

start_handler = CommandHandler('start', start)
dispatcher.add_handler(start_handler)


def help(update, context):
    context.bot.send_message(chat_id=update.effective_chat.id, text="/on - turn on the light\n/off - turn off the light")

help_handler = CommandHandler('help', help)
dispatcher.add_handler(help_handler)


def on(update, context):
     board.digital[13].write(1)
     context.bot.send_message(chat_id=update.effective_chat.id, text="pin 13 is on")
on_handler = CommandHandler('on', on)
dispatcher.add_handler(on_handler)


def off(update, context):
    board.digital[13].write(0)
    context.bot.send_message(chat_id=update.effective_chat.id, text="pin 13 is off")

off_handler = CommandHandler('off', off)
dispatcher.add_handler(off_handler)


def unknown(update, context):
    context.bot.send_message(chat_id=update.effective_chat.id, text="Sorry, I didn't understand that command.")

unknown_handler = MessageHandler(Filters.command, unknown)
dispatcher.add_handler(unknown_handler)





updater.start_polling()

